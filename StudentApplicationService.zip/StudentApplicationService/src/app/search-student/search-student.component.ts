import { Component, OnInit } from '@angular/core';
import { StudentService } from '../services/student.service';
import { StudentModel } from '../model/student-model';
@Component({
  selector: 'app-search-student',
  templateUrl: './search-student.component.html',
  styleUrls: ['./search-student.component.css']
})
export class SearchStudentComponent implements OnInit {
  public studentDetails: StudentModel;
  searchResult = false;
  rollno: number;
  constructor( private studentService: StudentService) {
    this.studentDetails = new StudentModel();
   }

  ngOnInit() {
  }
  searchStudent(rollno) {
    this.studentDetails = this.studentService.search(rollno);
    this.searchResult = true;
  }
}
