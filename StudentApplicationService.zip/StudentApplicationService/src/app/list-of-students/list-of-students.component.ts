import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StudentService } from '../services/student.service';

@Component({
  selector: 'app-list-of-students',
  templateUrl: './list-of-students.component.html',
  styleUrls: ['./list-of-students.component.css']
})
export class ListOfStudentsComponent implements OnInit {
  public students: any[];
  public editStatus = false;
  constructor(private router: Router, private studentService: StudentService) { }

  ngOnInit() {
    this.students = this.studentService.getStudentDetails();
  }
  navigateToRegister() {
    this.router.navigate(['/student-register']);
  }
  deleteRecord(index) {
    // delete record from service using index of record in array
    this.studentService.deleteStudentRecord(index);
  }
  editRecord(rollno) {
    this.editStatus = true;
    this.studentService.editStudentRecord(rollno);
  }
  sortByRollNo() {
    this.students =  this.studentService.sort();
  }
}
