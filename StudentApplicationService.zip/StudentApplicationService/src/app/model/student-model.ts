export class StudentModel {
    rollno: number;
    fname: String;
    email: String;
    address: String;
}
