import { Injectable } from '@angular/core';
import {Router} from '@angular/router';
import { StudentModel } from '../model/student-model';

@Injectable({
  providedIn: 'root'
})
export class StudentService {
  studentArrOfObj: StudentModel[];
  searchResult: StudentModel;
  editStatus = false; // maintains status for edit/submit data
  constructor(private router: Router) {
      this.studentArrOfObj = [];
   }

  setStudentDetails(studentDetails: StudentModel) {
    // push details object into array of objects
    this.studentArrOfObj.push(studentDetails);
    alert('Registered successfully!');
    this.router.navigate(['/list-of-students']);
  }
  getStudentDetails() {
  // retrive all records from array
   return this.studentArrOfObj;
  }
  deleteStudentRecord(index: any) {
    this.studentArrOfObj.splice(index , 1);
  }
  search(rollno: number) {
    this.searchResult = this.studentArrOfObj.find(x => x.rollno === rollno);
    if (this.searchResult === null) {
       return null;
    } else {
      return this.searchResult;
    }
  }

  sort() {
    this.studentArrOfObj.sort((a, b) => a.rollno > b.rollno ? 1 : ((a.rollno < b.rollno) ? -1 : 0));
    return this.studentArrOfObj;
  }
  editStudentRecord(rollno) {
    // set edit status to true to open registration form in edit mode
    this.editStatus = true;
    // fetch details
    this.searchResult = this.studentArrOfObj.find(x => x.rollno === rollno);
    this.router.navigate(['/student-register']);
  }
  getRecord() {
    // return fetched result to prefill data in register component
    return this.searchResult;
  }
}
