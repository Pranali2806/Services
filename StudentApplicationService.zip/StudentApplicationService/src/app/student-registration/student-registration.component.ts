import { Component, OnInit } from '@angular/core';
import { StudentService } from '../services/student.service';
import { ActivatedRoute, Router } from '@angular/router';
import { StudentModel } from '../model/student-model';

@Component({
  selector: 'app-student-registration',
  templateUrl: './student-registration.component.html',
  styleUrls: ['./student-registration.component.css']
})
export class StudentRegistrationComponent implements OnInit {
  studentDetails: StudentModel;
  buttonEditStatus = false;
  constructor(private studentService: StudentService, private route: ActivatedRoute, private router: Router) { 
    this.studentDetails = new StudentModel();
  }
  ngOnInit() {
      if (this.studentService.editStatus === true) {
        this.buttonEditStatus = true;
        // fetch previous data and prefill
        this.studentDetails = this.studentService.getRecord();
      } else {
        this.buttonEditStatus = false;
         // set all details to blank
        this.studentDetails = new StudentModel();
      }
  }
  onSubmit() {
    // set student details to service
    this.studentService.setStudentDetails(this.studentDetails);
  }
  update() {
    alert('Updated successfully!');
    // navigate to ListOfStudents page on update
    this.router.navigate(['/list-of-students']);
    this.studentService.editStatus = false;
  }
}
