import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StudentRegistrationComponent } from '../app/student-registration/student-registration.component';
import {Routes, RouterModule} from '@angular/router';
import { ListOfStudentsComponent } from './list-of-students/list-of-students.component';
import { SearchStudentComponent } from './search-student/search-student.component';

const routes: Routes = [
  { path: '', redirectTo: '/student-register', pathMatch: 'full' },
  { path: 'student-register', component: StudentRegistrationComponent},
  { path: 'list-of-students', component: ListOfStudentsComponent},
  { path: 'search-student', component: SearchStudentComponent}
];
@NgModule({
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ],
  declarations: [],
  exports: [ RouterModule ]
})
export class AppRoutingModule { }
